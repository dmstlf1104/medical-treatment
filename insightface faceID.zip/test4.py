import mysql.connector
import numpy as np
import cv2
import insightface
from sklearn.metrics.pairwise import cosine_similarity

# InsightFace 모델 로드
face_model = insightface.app.FaceAnalysis(name='buffalo_l')
face_model.prepare(ctx_id=0, det_size=(640, 640))

# MySQL 연결 설정
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '1234',
    'database': 'testdb'
}

# 전역 변수로 임베딩 캐시 저장
# 이 방식은 메모리 사용량이 증가합니다. 데이터베이스에 저장된 얼굴 수가 매우 많은 경우 메모리 사용량을 고려해야 합니다.
embedding_cache = {}

def load_embeddings():
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(buffered=True)

        query = "SELECT idx, embedding FROM userface"
        cursor.execute(query)

        for (idx, embedding_blob) in cursor:
            embedding_cache[idx] = np.frombuffer(embedding_blob, dtype=np.float32)

        print(f"임베딩 {len(embedding_cache)}개를 메모리에 로드했습니다.")

    except mysql.connector.Error as error:
        print(f"MySQL 쿼리 실행 중 오류 발생: {error}")

    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()

def find_similar_face(target_embedding, threshold=0.6):
    max_similarity = -1
    most_similar_idx = None

    for idx, db_embedding in embedding_cache.items():
        similarity = cosine_similarity(
            target_embedding.reshape(1, -1), 
            db_embedding.reshape(1, -1)
        )[0][0]

        if similarity > max_similarity:
            max_similarity = similarity
            most_similar_idx = idx

    if max_similarity > threshold:
        return most_similar_idx, max_similarity
    else:
        return None, max_similarity

def main():
    # 프로그램 시작 시 임베딩 로드
    load_embeddings()

    cap = cv2.VideoCapture(0)  # 웹캠 열기
    similarity_threshold = 0.7  # 유사도 임계값

    match_found = False  # 매치 찾음 플래그

    while not match_found:
        ret, frame = cap.read()
        if not ret:
            break

        # 프레임에서 얼굴 검출
        faces = face_model.get(frame)

        for face in faces:
            bbox = face.bbox.astype(int)
            embedding = face.embedding

            # 캐시된 임베딩과 비교
            similar_idx, similarity = find_similar_face(embedding, similarity_threshold)

            # 얼굴 주변에 박스 그리기
            cv2.rectangle(frame, (bbox[0], bbox[1]), (bbox[2], bbox[3]), (0, 255, 0), 2)

            # 결과 텍스트 표시
            if similar_idx is not None:
                text = f"ID: {similar_idx}, Sim: {similarity:.2f}"
                color = (0, 255, 0)  # 녹색 (매치된 경우)
                match_found = True  # 매치 찾음
            else:
                text = f"Unknown, Sim: {similarity:.2f}"
                color = (0, 0, 255)  # 빨간색 (매치되지 않은 경우)

            cv2.putText(frame, text, (bbox[0], bbox[1] - 10), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.9, color, 2)

        # 결과 표시
        cv2.imshow('Webcam Face Recognition', frame)

        # 'q' 키를 누르면 종료
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        # 매치된 얼굴을 찾았다면 1초 동안 결과를 보여주고 종료
        if match_found:
            cv2.waitKey(1000)
            break

    cap.release()
    cv2.destroyAllWindows()

    if match_found:
        print(f"매치된 얼굴을 찾았습니다. ID: {similar_idx}, 유사도: {similarity:.2f}")
    else:
        print("매치된 얼굴을 찾지 못했습니다.")

if __name__ == "__main__":
    main()