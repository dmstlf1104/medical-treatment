import cv2
import numpy as np
from insightface.app import FaceAnalysis
from insightface.data import get_image as ins_get_image

# FaceAnalysis 객체 초기화
app = FaceAnalysis(name='buffalo_l')
app.prepare(ctx_id=0, det_size=(640, 640))

# 이미지 로드
# img = ins_get_image('t1')
# 또는 로컬 이미지를 사용하려면:
img = cv2.imread('face_000.jpg')

# 얼굴 검출 및 특징 추출
faces = app.get(img)

# 결과 출력
for idx, face in enumerate(faces):
    bbox = face.bbox.astype(int)
    embedding = face.embedding
    
    print(f"Face {idx+1}:")
    print(f"  Bounding box: {bbox}")
    print(f"  Embedding shape: {embedding.shape}")
    print(f"  Embedding (first 10 elements): {embedding[:10]}")
    
    # 얼굴 영역 표시
    cv2.rectangle(img, (bbox[0], bbox[1]), (bbox[2], bbox[3]), (0, 255, 0), 2)

# 결과 이미지 표시
cv2.imshow('Result', img)
cv2.waitKey(0)
cv2.destroyAllWindows()