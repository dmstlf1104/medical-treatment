import mysql.connector
import insightface
import cv2
import numpy as np
import os

# InsightFace 모델 로드
face_model = insightface.app.FaceAnalysis()
face_model.prepare(ctx_id=0, det_size=(640, 640))

# MySQL 연결 설정
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '1234',
    'database': 'testdb'
}

# 이미지에서 얼굴 임베딩 추출
def get_face_embedding(image_path):
    img = cv2.imread(image_path)
    faces = face_model.get(img)
    if len(faces) > 0:
        return faces[0].embedding
    return None

# MySQL에 임베딩 저장
def save_embedding_to_mysql(embedding):
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()

        # 임베딩을 바이트 형식으로 변환
        embedding_bytes = embedding.tobytes()

        # SQL 쿼리 실행
        query = "INSERT INTO userface (embedding) VALUES (%s)"
        cursor.execute(query, (embedding_bytes,))

        idx = cursor.lastrowid  # 자동 생성된 idx 값을 가져옵니다

        conn.commit()
        print(f"임베딩이 성공적으로 저장되었습니다. (idx: {idx})")

    except mysql.connector.Error as error:
        print(f"MySQL에 임베딩을 저장하는 중 오류 발생: {error}")

    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()

# LFW 폴더 처리
def process_lfw_folder(lfw_path):
    total_processed = 0
    
    for person_folder in os.listdir(lfw_path):
        person_path = os.path.join(lfw_path, person_folder)
        if os.path.isdir(person_path):
            print(f"처리 중인 폴더: {person_folder}")
            image_files = sorted(os.listdir(person_path), reverse=True)
            for filename in image_files:
                if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                    image_path = os.path.join(person_path, filename)
                    embedding = get_face_embedding(image_path)
                    if embedding is not None:
                        save_embedding_to_mysql(embedding)
                        total_processed += 1
                        if total_processed >= 100:
                            print(f"총 {total_processed}개의 이미지 처리 완료")
                            return
            print(f"{person_folder} 폴더 처리 완료")

# 메인 실행 코드
if __name__ == "__main__":
    lfw_path = "lfw\lfw"  # LFW 폴더 경로
    process_lfw_folder(lfw_path)