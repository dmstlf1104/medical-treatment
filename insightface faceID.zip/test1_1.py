import cv2
import insightface
from insightface.app import FaceAnalysis
import numpy as np
import os
from datetime import datetime
import time

def bbox_iou(bbox1, bbox2):
    x1 = max(bbox1[0], bbox2[0])
    y1 = max(bbox1[1], bbox2[1])
    x2 = min(bbox1[2], bbox2[2])
    y2 = min(bbox1[3], bbox2[3])
    
    intersection = max(0, x2 - x1) * max(0, y2 - y1)
    area1 = (bbox1[2] - bbox1[0]) * (bbox1[3] - bbox1[1])
    area2 = (bbox2[2] - bbox2[0]) * (bbox2[3] - bbox2[1])
    
    iou = intersection / float(area1 + area2 - intersection)
    return iou

def capture_face():
    # FaceAnalysis 앱 초기화
    app = FaceAnalysis(providers=['CPUExecutionProvider'])
    app.prepare(ctx_id=0, det_size=(640, 640))

    # 웹캠 캡처 시작
    cap = cv2.VideoCapture(0)

    # 저장할 디렉토리 생성
    if not os.path.exists('captured_images'):
        os.makedirs('captured_images')

    # 얼굴 감지 지속 시간을 추적하기 위한 변수
    face_detected_time = None
    last_face_bbox = None
    captured_image_path = None

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        faces = app.get(frame)

        if len(faces) == 1:
            face = faces[0]
            bbox = face.bbox.astype(int)
            
            if last_face_bbox is None:
                last_face_bbox = bbox
                face_detected_time = time.time()
            else:
                iou = bbox_iou(last_face_bbox, bbox)
                if iou > 0.8:  # 80% 이상 겹치면 같은 얼굴로 간주
                    if time.time() - face_detected_time >= 3:
                        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                        captured_image_path = f'captured_images/captured_{timestamp}.jpg'
                        cv2.imwrite(captured_image_path, frame)
                        print(f"Image saved as {captured_image_path}")
                        break  # 사진을 찍고 루프 종료
                else:
                    last_face_bbox = bbox
                    face_detected_time = time.time()
            
            cv2.rectangle(frame, (bbox[0], bbox[1]), (bbox[2], bbox[3]), (0, 255, 0), 2)
        else:
            last_face_bbox = None
            face_detected_time = None

        cv2.imshow('Webcam Face Detection', frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # 자원 해제
    cap.release()
    cv2.destroyAllWindows()

    return captured_image_path

def show_captured_image(image_path):
    if image_path and os.path.exists(image_path):
        img = cv2.imread(image_path)
        cv2.imshow('Captured Image', img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    else:
        print("Image not found or invalid path.")

def main():
    captured_image = capture_face()
    if captured_image:
        print(f"Captured image path: {captured_image}")
        show_captured_image(captured_image)
    else:
        print("No image was captured.")
    return captured_image

if __name__ == "__main__":
    main()