import mysql.connector
import numpy as np
import cv2
import insightface
from sklearn.metrics.pairwise import cosine_similarity

# InsightFace 모델 로드
face_model = insightface.app.FaceAnalysis(name='buffalo_l')
print(face_model.models)
face_model.prepare(ctx_id=0, det_size=(640, 640))

# MySQL 연결 설정
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '1234',
    'database': 'testdb'
}

def get_face_embedding(image_path):
    img = cv2.imread(image_path)
    faces = face_model.get(img)
    if len(faces) > 0:
        return faces[0].embedding
    return None

def find_similar_face(target_embedding, threshold=0.6):
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(buffered=True)

        # 모든 임베딩 데이터 가져오기
        query = "SELECT idx, embedding FROM userface"
        cursor.execute(query)

        max_similarity = -1
        most_similar_idx = None

        for (idx, embedding_blob) in cursor:
            # BLOB 데이터를 numpy 배열로 변환
            db_embedding = np.frombuffer(embedding_blob, dtype=np.float32)
            
            similarity = cosine_similarity(
                target_embedding.reshape(1, -1), 
                db_embedding.reshape(1, -1)
            )[0][0]

            if similarity > max_similarity:
                max_similarity = similarity
                most_similar_idx = idx

        if max_similarity > threshold:
            return most_similar_idx, max_similarity
        else:
            return None, max_similarity

    except mysql.connector.Error as error:
        print(f"MySQL 쿼리 실행 중 오류 발생: {error}")
        return None, -1

    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()

# 메인 실행 코드
if __name__ == "__main__":
    target_image_path = "face_000.jpg"  # 대상 이미지 경로
    similarity_threshold = 0.7  # 유사도 임계값 (0.0 ~ 1.0)

    target_embedding = get_face_embedding(target_image_path)
    
    if target_embedding is not None:
        similar_idx, similarity = find_similar_face(target_embedding, similarity_threshold)
        
        if similar_idx is not None:
            print(f"가장 유사한 얼굴의 idx: {similar_idx}")
            print(f"유사도: {similarity:.4f}")
        else:
            print(f"임계값({similarity_threshold})을 넘는 유사한 얼굴을 찾지 못했습니다.")
            print(f"가장 높은 유사도: {similarity:.4f}")
    else:
        print("대상 이미지에서 얼굴을 찾을 수 없습니다.")