import requests

def ocr_to_word_list(filename, api_key, url):
    headers = {"Authorization": f"Bearer {api_key}"}

    with open(filename, "rb") as file:
        files = {"document": file}
        response = requests.post(url, headers=headers, files=files)
        
    if response.status_code == 200:
        result = response.json()
        # JSON 구조에 따라 텍스트 추출
        # 이 부분은 JSON 응답 구조에 따라 조정 필요
        text = result.get('text', '')  # 'text' 키에 해당하는 값 추출
        
        # 텍스트를 단어 단위로 분리하여 리스트로 만듦
        word_list = text.split()
        return word_list
    else:
        return []  # 오류 발생 시 빈 리스트 반환

if __name__ == "__main__":
    api_key = "up_8sqFsKHvhK5EqZeiO8p8DfjXG2yZ7"
    url = "https://api.upstage.ai/v1/document-ai/ocr"
    filename = "file.jpg"

    result_list = ocr_to_word_list(filename, api_key)
    # 결과 확인을 위한 출력 (필요시 주석 해제)
    print(result_list)