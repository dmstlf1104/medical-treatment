import mysql.connector
from getpass import getpass
from werkzeug.security import check_password_hash

# MySQL 연결 설정
db = mysql.connector.connect(
    host="192.168.1.5",
    user="tester",
    password="1234",
    database="medical_records_db"
)

def login():
    print("로그인을 시작합니다.")
    
    user_id = input("사용자 ID를 입력하세요: ")
    password = getpass("비밀번호를 입력하세요: ")

    cursor = db.cursor(dictionary=True)

    # 사용자 정보 조회 쿼리
    sql = "SELECT * FROM users WHERE user_id = %s"
    cursor.execute(sql, (user_id,))
    
    user = cursor.fetchone()
    
    if user and check_password_hash(user['password'], password):
        print("로그인 성공!")
        return True
    else:
        print("로그인 실패. 사용자 ID 또는 비밀번호를 확인해주세요.")
        return False

    cursor.close()

if __name__ == '__main__':
    login()
    db.close()