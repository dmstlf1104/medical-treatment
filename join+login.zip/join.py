import mysql.connector
from getpass import getpass
from werkzeug.security import generate_password_hash

# MySQL 연결 설정
db = mysql.connector.connect(
    host="192.168.1.5",
    user="tester",
    password="1234",
    database="medical_records_db"
)

def signup():
    print("회원가입을 시작합니다.")
    
    username = input("사용자 이름을 입력하세요: ")
    gender = input("성별을 입력하세요 (male/female): ")
    ssn_first = input("주민등록번호 앞 6자리를 입력하세요 (YYMMDD): ")
    user_id = input("사용자 ID를 입력하세요: ")
    password = getpass("비밀번호를 입력하세요: ")

    # 비밀번호 해싱
    hashed_password = generate_password_hash(password)

    cursor = db.cursor()

    # 사용자 정보 삽입 쿼리
    sql = "INSERT INTO users (username, gender, ssn_first, user_id, password) VALUES (%s, %s, %s, %s, %s)"
    values = (username, gender, ssn_first, user_id, hashed_password)

    try:
        cursor.execute(sql, values)
        db.commit()
        print("회원가입이 성공적으로 완료되었습니다!")
    except mysql.connector.Error as err:
        db.rollback()
        print(f"회원가입 실패: {err}")
    finally:
        cursor.close()

if __name__ == '__main__':
    signup()
    db.close()