import sqlite3
import re
import upstage_list as u
import requests
import mysql.connector

def search_terms(search_query):
    try:
        conn = mysql.connector.connect(
            host="192.168.1.2",
            user="tester",
            password="1234",
            database="medical_terms_split"
        )
        cursor = conn.cursor()
        
        # term_ko와 term_en을 가져옴
        cursor.execute("SELECT term_ko, term_en, explanation FROM terms")
        all_results = cursor.fetchall()
        
        # term_ko와 term_en과 비교하여 결과 필터링
        filtered_results = [
            (term_ko, term_en, explanation) for term_ko, term_en, explanation in all_results
            if search_query == term_ko or search_query == term_en
        ]
        
        return filtered_results
    
    except mysql.connector.Error as e:
        print(f"An error occurred: {e}")
        return []
    
    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()


def main():
    
    api_key = "up_8sqFsKHvhK5EqZeiO8p8DfjXG2yZ7"
    url = "https://api.upstage.ai/v1/document-ai/ocr"
    filename = "file.jpg"

    # OCR 수행
    result = u.ocr_to_word_list(filename, api_key, url)
    result = set(result)
    result = list(result)
    
    for result_X in result:
        results = search_terms(result_X)
        
        if results:
            print(f"\n'{result_X}'에 대한 검색 결과:")
            for term_ko, term_en, explanation in results:
                print(f"한국어 용어: {term_ko}")
                print(f"영어 용어: {term_en}")
                print("설명:")
                print(explanation)
        
        # print()  # 빈 줄 출력

if __name__ == "__main__":
    main()